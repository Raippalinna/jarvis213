---
name: jarvis-ai-verktygskedja
description: "Jarvis kostnadsmedvetna AI-orkestrering: välj kod, modell, Comet, dator, ChatGPT/Codex, Cursor, Lovable eller skill. Använd vid koppling av AI-verktyg, billigare modellval, datoruppdrag och granskade förbättringsförslag. Inte för connector-hälsa, tjänsteägarskap mellan Notion/Supabase/Slack eller BTF-kalkyl."
metadata:
  author: ricky-raippalinna
  version: '1.1'
  perplexity:
    connectors:
      - id: github_mcp_direct
        reason: GitHub är bryggan mellan Jarvis, Codex cloud och Cursor; utan den kan inte PR:ar granskas eller AGENTS.md hållas i synk.
      - id: slack_direct
        reason: Kandidatkanal för Cursor Background Agents och Codex-notiser.
      - id: supabase
        reason: Läs system_config.autonomy_enabled före autonom sidoeffekt.
---

# Jarvis AI-verktygskedja

Perplexity Computer är orkestratorn. ChatGPT, Codex, Cursor och Lovable är utförandearmar som möts i
GitHub (`rickyraippalinna/jarvis-omega-v2` för automation, Lovable-repona för apparna); `AGENTS.md` i
varje repo bär Jarvis-reglerna in i dem.
Lägg inte till en ny arm om en befintlig redan täcker behovet; fler råa verktyg sänker träffsäkerheten.

## Välj minsta tillräckliga väg

Läs `references/kostnadsmedveten-orkestrering.md` före val som påverkar modellnivå,
abonnemangsåterbruk, automatisk synk eller förslag till självförbättring.
Läs `references/verktygsval.md` när uppgiften ska fördelas till en konkret AI-arm.
Utgå inte från att fler modeller är bättre; använd testbara kvalitetskrav och relevanta källor.

## Arbetsordning vid kodärende till Codex eller Cursor

1. Läs `AGENTS.md` och aktuell branch i repot med `gh`/`git` (credential `github`); bekräfta att inga push-triggade workflows startar kostnad.
2. Läs `system_config.autonomy_enabled` i Jarvis-Supabase; false eller okänt = ingen autonom sidoeffekt, bara förberedelse.
3. Formulera uppdraget med mål, filer, testkommando och förbjudna ändringar (hemligheter, kill switch, DRY_RUN, workflows med kostnad). Skicka via Codex cloud-UI i lokal webbläsare eller som GPT-subagent i sandboxen.
4. Hämta PR:en, kör `git diff` och testerna själv i sandboxen; leta hemligheter i diffen.
5. Rapportera status: FÖRBERETT, TESTAT LOKALT, SPARAT (PR öppen), DRIFTSATT (merge, kräver godkännande), VERIFIERAT I DRIFT (körning observerad).

Klart när PR-länk, testresultat och återstående blockerare är redovisade. En öppnad Codex-uppgift är inte en merge; en inloggad tjänst är inte ett verifierat flöde.

## Läs vid behov

- `references/status-och-aktivering.md`: daterad status per arm (ChatGPT-plan, Codex-miljöer, Cursor och Lenovo-begränsningar) och aktiveringssteg. Läs när en arm saknas, felar eller när användaren frågar vad som återstår.
